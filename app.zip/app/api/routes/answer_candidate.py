from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, UTC
from uuid import UUID

from app.db.session import get_db
from app.models.core import AnswerCandidate
from app.models.enums import CandidateStatus
from app.services.candidate_service import create_knowledge_from_candidate

router = APIRouter(prefix="/answer-candidate", tags=["Answer Candidate"])


# ==============================
# GET LIST CANDIDATES
# ==============================
@router.get("")
def list_candidates(
    status: CandidateStatus | None = None,
    db: Session = Depends(get_db),
):
    query = db.query(AnswerCandidate)

    if status:
        query = query.filter(AnswerCandidate.status == status)

    candidates = query.order_by(AnswerCandidate.created_at.desc()).all()

    return candidates


# ==============================
# APPROVE CANDIDATE
# ==============================
@router.post("/{candidate_id}/approve")
def approve_candidate(
    candidate_id: UUID,
    db: Session = Depends(get_db),
):
    candidate = db.query(AnswerCandidate).filter(
        AnswerCandidate.id == candidate_id
    ).first()

    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")

    # 🔒 tránh approve lại
    if candidate.status == CandidateStatus.APPROVED:
        return {"message": "Already approved"}

    # ✅ cập nhật trạng thái
    candidate.status = CandidateStatus.APPROVED
    candidate.final_text = candidate.draft_text
    candidate.reviewed_at = datetime.now(UTC)

    db.commit()
    db.refresh(candidate)

    # 🚀 P4-04: tạo knowledge
    create_knowledge_from_candidate(db, candidate)

    return {
        "message": "Candidate approved",
        "candidate_id": str(candidate.id),
    }


# ==============================
# REJECT CANDIDATE
# ==============================
from fastapi import Body

@router.post("/{candidate_id}/approve")
def approve_candidate(
    candidate_id: UUID,
    final_text: str | None = Body(default=None),
    db: Session = Depends(get_db),
):
    candidate = db.query(AnswerCandidate).filter(
        AnswerCandidate.id == candidate_id
    ).first()

    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")

    if candidate.status == CandidateStatus.APPROVED:
        return {"message": "Already approved"}

    # 🔥 LOGIC MỚI
    if final_text:
        candidate.final_text = final_text
    else:
        candidate.final_text = candidate.draft_text

    candidate.status = CandidateStatus.APPROVED
    candidate.reviewed_at = datetime.now(UTC)

    db.commit()
    db.refresh(candidate)

    # tạo knowledge
    create_knowledge_from_candidate(db, candidate)

    return {
        "message": "Candidate approved",
        "candidate_id": str(candidate.id),
    }