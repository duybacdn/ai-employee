from fastapi import APIRouter, Request, Response
import logging

from app.services.parsers.facebook_parser import parse_facebook_event
from app.services.message_service import handle_incoming_message
from app.core.database import SessionLocal

router = APIRouter()
logger = logging.getLogger(__name__)

VERIFY_TOKEN = "your_verify_token"


# ✅ VERIFY (GET)
@router.get("/webhook/facebook")
async def verify_webhook(request: Request):
    params = request.query_params

    if (
        params.get("hub.mode") == "subscribe"
        and params.get("hub.verify_token") == VERIFY_TOKEN
    ):
        return Response(content=params.get("hub.challenge"), media_type="text/plain")

    return Response(content="Verification failed", status_code=403)


@router.post("/webhook/facebook")
async def receive_webhook(request: Request):
    body = await request.json()

    logger.info(f"📩 RAW EVENT: {body}")

    messages = parse_facebook_event(body) or []

    logger.info(f"📨 PARSED MESSAGES: {messages}")

    db = SessionLocal()

    try:
        for msg in messages:
            try:
                # 🔥 Validate lần cuối (double safety)
                if not msg.get("sender_id") or not msg.get("text"):
                    logger.warning(f"⚠️ Invalid message skipped: {msg}")
                    continue

                handle_incoming_message(db, msg)

            except Exception as e:
                logger.error(f"❌ Error processing message {msg}: {e}")

    finally:
        db.close()

    return {"status": "ok"}