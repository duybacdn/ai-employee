def parse_facebook_event(event):
    messages = []

    try:
        for entry in event.get("entry", []):
            page_id = entry.get("id")

            for messaging_event in entry.get("messaging", []):

                sender_id = messaging_event.get("sender", {}).get("id")
                recipient_id = messaging_event.get("recipient", {}).get("id")
                timestamp = messaging_event.get("timestamp")

                message = messaging_event.get("message")
                if not message:
                    continue

                text = message.get("text")

                # 🔥 Skip nếu thiếu dữ liệu quan trọng
                if not sender_id or not text:
                    continue

                messages.append({
                    "sender_id": sender_id,
                    "page_id": recipient_id or page_id,
                    "text": text,
                    "timestamp": timestamp
                })

    except Exception as e:
        print("Parse error:", e)

    return messages  # 🔥 QUAN TRỌNG