# app/services/facebook_service.py

import requests
import os

PAGE_ACCESS_TOKEN = os.getenv("FACEBOOK_PAGE_ACCESS_TOKEN")

def send_message(psid: str, text: str):
    url = "https://graph.facebook.com/v18.0/me/messages"

    payload = {
        "recipient": {"id": psid},
        "message": {"text": text}
    }

    params = {
        "access_token": PAGE_ACCESS_TOKEN
    }

    try:
        response = requests.post(url, json=payload, params=params)

        if response.status_code != 200:
            print("❌ Facebook API Error:", response.text)
        else:
            print("📤 Sent message to Facebook")

    except Exception as e:
        print("❌ Send message failed:", e)