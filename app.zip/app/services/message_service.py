import uuid
from sqlalchemy.orm import Session
from app.models.core import Message, Conversation
from app.models.enums import MessageDirection, MessageKind
from app.models.core import Contact, ContactIdentity, Conversation
from app.models.enums import Platform, ConversationStatus
from app.services.queue import message_queue
from app.workers.message_worker import process_incoming_message

import uuid

def save_message(db, *, company_id, channel_id, contact_id, conversation_id, text):
    msg = Message(
        id=uuid.uuid4(),
        company_id=company_id,
        channel_id=channel_id,
        contact_id=contact_id,
        conversation_id=conversation_id,
        direction=MessageDirection.INBOUND,
        kind=MessageKind.INBOX,
        text=text,
    )

    db.add(msg)
    db.commit()
    db.refresh(msg)

    return msg

import logging

logger = logging.getLogger(__name__)

def handle_incoming_message(db, message):
    try:
        sender_id = message.get("sender_id")
        text = message.get("text")

        if not sender_id or not text:
            print(f"⚠️ Invalid message skipped: {message}")
            return

        print(f"📨 Processing message from {sender_id}")

        # 🔥 HARD CODE (MVP)
        company_id = uuid.UUID("00000000-0000-0000-0000-000000000001")
        channel_id = uuid.UUID("00000000-0000-0000-0000-000000000001")

        # =========================
        # 1. FIND / CREATE CONTACT
        # =========================
        identity = (
            db.query(ContactIdentity)
            .filter_by(
                company_id=company_id,
                platform=Platform.FACEBOOK,
                external_user_id=sender_id,
            )
            .first()
        )

        if not identity:
            contact = Contact(
                id=uuid.uuid4(),
                company_id=company_id,
            )
            db.add(contact)
            db.commit()
            db.refresh(contact)

            identity = ContactIdentity(
                id=uuid.uuid4(),
                company_id=company_id,
                contact_id=contact.id,
                platform=Platform.FACEBOOK,
                external_user_id=sender_id,
            )
            db.add(identity)
            db.commit()
            db.refresh(identity)

        contact = identity.contact

        # =========================
        # 2. FIND / CREATE CONVERSATION
        # =========================
        conversation = (
            db.query(Conversation)
            .filter_by(
                company_id=company_id,
                channel_id=channel_id,
                contact_id=contact.id,
            )
            .first()
        )

        if not conversation:
            conversation = Conversation(
                id=uuid.uuid4(),
                company_id=company_id,
                channel_id=channel_id,
                contact_id=contact.id,
                status=ConversationStatus.OPEN,
            )
            db.add(conversation)
            db.commit()
            db.refresh(conversation)

        # =========================
        # 3. SAVE MESSAGE
        # =========================
        saved = save_message(
            db,
            company_id=company_id,
            channel_id=channel_id,
            contact_id=contact.id,
            conversation_id=conversation.id,
            text=text,
        )

        print(f"💾 Saved message ID: {saved.id}")

        # 👇 THÊM ĐOẠN NÀY (P2-07)
        message_queue.enqueue(
            process_incoming_message,
            str(saved.id),
            job_timeout=None   # 🔥 QUAN TRỌNG
        )

        print(f"📤 Pushed message {saved.id} to Redis queue")

    except Exception as e:
        print(f"❌ Error processing message {message}: {e}")