from qdrant_client import QdrantClient
from qdrant_client.models import VectorParams, Distance
import os

# ===== CONFIG =====
QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
COLLECTION_NAME = "knowledge"
VECTOR_SIZE = 1536  # OpenAI embedding size

# ===== CLIENT =====
qdrant = QDRANTClient = QdrantClient(url=QDRANT_URL)

# ===== CREATE COLLECTION (if not exists) =====
def init_qdrant():
    collections = qdrant.get_collections().collections
    names = [c.name for c in collections]

    if COLLECTION_NAME not in names:
        qdrant.create_collection(
            collection_name=COLLECTION_NAME,
            vectors_config=VectorParams(
                size=VECTOR_SIZE,
                distance=Distance.COSINE
            )
        )
        print(f"✅ Created collection: {COLLECTION_NAME}")
    else:
        print(f"✅ Collection exists: {COLLECTION_NAME}")


def search_knowledge(query: str, company_id: str, top_k: int = 3):
    from app.services.embedding_service import get_embedding

    print("\n🔍 SEARCH KNOWLEDGE")
    print("👉 Query:", query)
    print("👉 Company ID:", company_id)

    query_vector = get_embedding(query)

    results = qdrant.query_points(
        collection_name=COLLECTION_NAME,
        query=query_vector,
        limit=top_k,
        with_payload=True
    )

    knowledge_list = []

    print(f"📊 Found {len(results.points)} raw results")

    for point in results.points:
        payload = point.payload or {}

        print("👉 Payload:", payload)

        if payload.get("company_id") != company_id:
            print("❌ Skip (company mismatch)")
            continue

        content = payload.get("content")
        if content:
            print("✅ Add:", content)
            knowledge_list.append(content)

    print("📚 FINAL KNOWLEDGE:", knowledge_list)

    return knowledge_list