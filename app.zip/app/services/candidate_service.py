from app.models.core import KnowledgeItem
from app.services.embedding_service import get_embedding
from app.services.qdrant_service import qdrant, COLLECTION_NAME


def create_knowledge_from_candidate(db, candidate):
    # 🛡️ tránh duplicate
    existing = db.query(KnowledgeItem).filter(
        KnowledgeItem.source_candidate_id == candidate.id
    ).first()

    if existing:
        return existing

    knowledge = KnowledgeItem(
        company_id=candidate.company_id,
        employee_id=candidate.employee_id,
        source_candidate_id=candidate.id,  # 🔥 LINK
        source="approved_candidate",
        title=None,
        content=candidate.final_text,
    )
    
    db.add(knowledge)
    db.commit()
    db.refresh(knowledge)
    index_knowledge_item(knowledge)
    return knowledge

def index_knowledge_item(knowledge):
    vector = get_embedding(knowledge.content)

    qdrant.upsert(
        collection_name=COLLECTION_NAME,
        points=[
            {
                "id": str(knowledge.id),
                "vector": vector,
                "payload": {
                    "company_id": str(knowledge.company_id),
                    "content": knowledge.content,
                }
            }
        ]
    )