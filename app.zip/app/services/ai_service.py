import json
from openai import OpenAI
import os

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def call_ai(prompt: str) -> str:
    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {
                    "role": "system",
                    "content": "Bạn là AI Employee. Luôn trả về JSON hợp lệ, không thêm text ngoài JSON."
                },
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
        )

        content = response.choices[0].message.content.strip()

        # 🔥 Clean nếu AI bọc ```json
        if content.startswith("```"):
            content = content.replace("```json", "").replace("```", "").strip()

        return content

    except Exception as e:
        print(f"❌ AI Error: {e}")

        # fallback JSON chuẩn (KHÔNG crash hệ thống)
        return json.dumps({
            "reply": "Xin lỗi, hệ thống đang bận. Vui lòng thử lại sau.",
            "classification": "inbox",
            "tags": []
        })