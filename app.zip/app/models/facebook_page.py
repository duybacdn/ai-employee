from sqlalchemy import Column, Integer, String, ForeignKey
from app.db.base import Base

class FacebookPage(Base):
    __tablename__ = "facebook_pages"

    id = Column(Integer, primary_key=True, index=True)
    page_id = Column(String, unique=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"))