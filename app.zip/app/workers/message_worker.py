import datetime
from app.db.session import SessionLocal
from app.models.core import Conversation, Message, MessageDirection, MessageKind
from app.services.ai_prompt_builder import build_ai_prompt
from app.services.ai_prompt_builder import build_ai_prompt
from app.services.ai_service import call_ai
import json
from app.services.facebook_service import send_message
from app.models.core import ContactIdentity
from app.models.enums import Platform
from app.services.qdrant_service import search_knowledge

# 🔥 THÊM DÒNG NÀY
DEFAULT_EMPLOYEE_ID = "8f0aa3ac-41c3-480d-bc16-e735179b58c6"

def process_incoming_message(message_id: str):
    print(f"🔧 Processing message {message_id}")

    db = SessionLocal()
    try:
        message = db.query(Message).filter(Message.id == message_id).first()

        if not message:
            print("❌ Message not found")
            return

        # ================================
        # 🔥 P6-02: SEARCH KNOWLEDGE
        # ================================
        from app.services.qdrant_service import search_knowledge

        knowledge_list = search_knowledge(
            query=message.text,
            company_id=str(message.company_id)
        )

        print("=== USER MESSAGE ===", message.text)
        print("=== KNOWLEDGE RETRIEVED ===")
        for k in knowledge_list:
            print("-", k)

        # ================================
        # 🔥 BUILD KNOWLEDGE CONTEXT
        # ================================
        if knowledge_list:
            knowledge_text = "\n".join(
                [f"{i+1}. {k}" for i, k in enumerate(knowledge_list)]
            )
        else:
            knowledge_text = "No relevant company knowledge."

        # ================================
        # 🔥 P6-03: BUILD PROMPT (RAG)
        # ================================
        prompt = f"""
You are an AI employee of the company.

Use ONLY the company knowledge below to answer the user.
If the answer is not in the knowledge, say you don't know.

Company knowledge:
{knowledge_text}

User message:
{message.text}

Answer naturally and clearly.
"""

        # ================================
        # CALL AI
        # ================================
        ai_response = call_ai(prompt)

        print("🤖 RAW AI RESPONSE:")
        print(ai_response)

        # Parse
        parsed = parse_ai_response(ai_response)

        reply_text = parsed["reply"]
        classification = parsed["classification"]
        tags = parsed["tags"]

        print("✅ PARSED:", parsed)

        # Map enum
        message_kind = map_classification(classification)

        # 👉 Tạo message outbound (AI reply)
        reply_message = Message(
            company_id=message.company_id,
            conversation_id=message.conversation_id,
            channel_id=message.channel_id,
            contact_id=message.contact_id,
            direction=MessageDirection.OUTBOUND,
            kind=message_kind,
            text=reply_text,
            employee_id=message.employee_id or DEFAULT_EMPLOYEE_ID,
        )

        db.add(reply_message)
        db.flush()

        # 🔥 TẠO ANSWER CANDIDATE
        from app.models.core import AnswerCandidate, CandidateStatus

        candidate = AnswerCandidate(
            company_id=message.company_id,
            message_id=message.id,
            employee_id=message.employee_id or DEFAULT_EMPLOYEE_ID,
            draft_text=reply_text,
            status=CandidateStatus.PENDING,
        )

        db.add(candidate)

        db.commit()

        print(f"✅ Candidate saved: {candidate.id}")

        # ================================
        # SEND FACEBOOK
        # ================================
        identity = (
            db.query(ContactIdentity)
            .filter_by(
                contact_id=message.contact_id,
                platform=Platform.FACEBOOK
            )
            .first()
        )

        if not identity:
            print("❌ No Facebook identity found")
            return

        psid = identity.external_user_id

        send_message(psid, reply_text)

        print(f"📤 Sent reply to PSID: {psid}")
        print(f"💬 Saved reply message: {reply_text}")
        print(f"🏷 Tags: {tags}")

    except Exception as e:
        db.rollback()
        print(f"❌ Error: {e}")
    finally:
        db.close()

def parse_ai_response(ai_response: str):
    try:
        data = json.loads(ai_response)

        return {
            "reply": data.get("reply", "").strip(),
            "classification": data.get("classification", "inbox"),
            "tags": data.get("tags", [])
        }

    except Exception as e:
        print("❌ JSON parse failed:", e)
        print("RAW:", ai_response)

        # fallback an toàn
        return {
            "reply": "Xin lỗi, tôi chưa hiểu rõ. Bạn có thể nói rõ hơn không?",
            "classification": "inbox",
            "tags": []
        }
    
def map_classification(value: str):
    value = value.lower()

    if value == "comment":
        return MessageKind.COMMENT
    elif value == "system":
        return MessageKind.SYSTEM
    else:
        return MessageKind.INBOX